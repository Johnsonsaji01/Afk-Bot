module.exports.performance = window.performance
