## Standalone

```js
npm install
npm run build-start
```